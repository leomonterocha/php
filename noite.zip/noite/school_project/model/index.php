<?php

	include_once dirname(__DIR__).'/model/config.php';

	header("location: $project_index?error=acess_denied_for_acrchives");


?>
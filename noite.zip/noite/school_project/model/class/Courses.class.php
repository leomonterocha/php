<?php  

	class Courses{

		private $course_name;
		private $course_description;
		private $course_hour;


		public function set_course_name($course_name){
			$this->course_name = $course_name;
		}

		public function get_course_name(){
			return $this->course_name;
		}

		public function set_course_description($course_description){
			$this->course_description = $course_description;
		}

		public function get_course_description(){
			return $this->course_description;
		}

		public function set_course_hour($course_hour){
			$this->course_hour = $course_hour;
		}

		public function get_course_hour(){
			return $this->course_hour;
		}

	}



?>
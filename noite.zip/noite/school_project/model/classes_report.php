<?php


	# Definindo o dietório de fontes dos pdf
	define('FPDF_FONTPATH', 'font/');

	# Incluindo o arquivo de configuração	
	include_once 'config.php';

	# incluindo o arquivo FPDF
	include_once 'class/fpdf/FPDF.class.php';

	#Incluindo as classes necessárias
	include_once 'class/Connect.class.php';
	include_once 'class/Manager.class.php';
	include_once 'class/fpdf/PDFS.class.php';

	//echo $project_path;

	# Criando o Objeto do PDF
	$pdf = new Pdfs();
	
	# Título do PDF
	$pdf->SetTitle("a");


	$pdf->SetFillColor(211,211,211);
	# Parametros : Tipo do Formato do pdf (Landscape, Portrait)
	# Tipo de Página - A3, A4, A5 ETC... 
	$pdf->title = utf8_decode("Turmas da Escola do Poder");
	
	# Método Add Page - Adiciona Uma página: 
	$pdf->AddPage('L',"A4");

	# Tipo da fonte do PDF
	# Fonte do pdf (nome), Estilo da Fonte (B, U, I), Tamanho da Fonte
	$pdf->SetFont('Arial', 'B', 11);
	//$pdf->ln(10);	
	# Método Cell:  Largura, Altura, Título, Borda, Posição da Proxima Célula(0,1), Posição do texto (C - centralizado, R - direita, L - esquerda)->
	$pdf->Cell(100, 10, 'Nome do Professor',1 , 0, 'C');
	$pdf->Cell(70, 10, 'Nome do Curso',1 , 0, 'C');
	$pdf->Cell(50, 10, utf8_decode('Horários do Curso'),1 , 0, 'C');
	$pdf->Cell(57, 10, utf8_decode('Descricão'),1 , 1, 'C');
	
	$manager = new Manager();

	$users = $manager->select_common("tb_users",null, null,null);

	foreach ($users as $user) {
		$pdf->Cell(100, 10, utf8_decode($user['user_name']),1 , 0, 'C');
		$pdf->Cell(70, 10, utf8_decode($user['user_phone']),1 , 0, 'C');
		$pdf->Cell(50, 10, utf8_decode($user['user_cellphone']),1 , 0, 'C');
		$pdf->Cell(57, 10, utf8_decode($user['user_email']),1 , 1, 'C');			
	}	


	//Fechando o PDF
	$pdf->Output();
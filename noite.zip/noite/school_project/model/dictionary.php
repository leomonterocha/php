<?php

	$GLOBALS['dictionary'] = array(

		'login_ok'=> "Bem vind@ ao sistema escolar!",
		'session_ending'=>"Sessão Encerrada!",
		'user_not_found'=>"Usuário não encontrado!",
		'password_incorrect'=>"Senha Incorreta!",

	);


?>
<?php  
	# Arquivo de configuração
	include_once 'model/config.php';
	###################################
?>
	<!-- Link do CSS do Bootstrap -->
	<link rel="stylesheet" href="<?php echo $project_index; ?>/view/assets/bootstrap/css/bootstrap.css">
	<!-- Link do CSS do Font Awesome -->
	<link rel="stylesheet" href="<?php echo $project_index; ?>/view/assets/font-awesome/css/font-awesome.min.css">
	<!-- Link do CSS do Sidebar -->
	<link href="<?php echo $project_index; ?>/view/assets/external_css/simple-sidebar.css" rel="stylesheet">

	<!-- Link do JS do Jquery -->
	<script src="<?php echo $project_index; ?>/view/assets/bootstrap/js/jquery.js">
	</script>
	
	<!-- Link do JS do JavaScript do Bootstrap -->
	<script src="<?php echo $project_index; ?>/view/assets/bootstrap/js/bootstrap.js">
	</script>

	<!-- Link do JS do DataTables -->
	<script src="<?php echo $project_index; ?>/view/assets/external_js/data-tables/data_tables.min.js"></script>

	<!-- Link do JS do JqueryMask -->
	<script src="<?php echo $project_index; ?>/view/assets/external_js/jquery-mask/jquery.mask.js"></script>

<?php
	include_once 'model/class/Connect.class.php';
	include_once 'model/class/Manager.class.php';

	# Criar um objeto do tipo Manager
	$manager = new Manager();

	# Chamando o método de seleção e guardando os dados para a tabela
	$table_content = $manager->select_common("tb_users",null,null,null);

	# Renderizando os títulos da tabela
	//$table_titles["id_course"] = "ID";
	$table_titles["user_name"] = "Nome do Curso";
	$table_titles["user_email"] = "Eamil";
	//$table_titles["course_description"] = "Descrição";
	//$table_titles["course_hour"] = "Horário";

	# Ações no banco
	$update = false;
	$delete = false;

	# Caminhos dos Arquivos
	$delete_destiny = "controller/delete_user.php";

	# Filtro
	$filter = "id_user"; 


	##################################
	include_once 'view/list_common.html';
?>